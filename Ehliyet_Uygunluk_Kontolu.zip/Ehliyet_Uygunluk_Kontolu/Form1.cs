﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ehliyet_Uygunluk_Kontolu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime bugunTarihi = DateTime.Now;
            DateTime KullaniciDogumarihi = monthCalendar1.SelectionStart;
            DateTime OnSekizYilSonrasi = KullaniciDogumarihi.AddYears(18);
      
            TimeSpan ts = bugunTarihi - OnSekizYilSonrasi;
            label2.Text = "Doğum Tarihi : " + KullaniciDogumarihi.ToShortDateString();
            if (bugunTarihi >= OnSekizYilSonrasi)
            {
                label3.Text = "Geçen Gün Sayısı: " + ts.Days.ToString();
            }
            else
            {
                label3.Text = "Kalan Gün Sayısı: " + ts.Days.ToString();
            }

            label5.Text = "Ehliyet Tarihi :" + OnSekizYilSonrasi.ToShortDateString();
            if (bugunTarihi >= OnSekizYilSonrasi)
            {
                label6.Text = "Durumu : Ehliyet Alabilir";
            }
            else
            {
                label6.Text = "Durumu : Ehliyet Alamaz ";
            }
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }
    }
}
